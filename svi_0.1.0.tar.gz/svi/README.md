R package for the direct SVI implied volatility calibration
